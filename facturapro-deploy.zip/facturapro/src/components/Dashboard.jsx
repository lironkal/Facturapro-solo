import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import InvoiceEditor from './InvoiceEditor';

export default function Dashboard({ user }) {
  const [invoices, setInvoices] = useState([]);
  const [view, setView] = useState('list'); // list | new | edit
  const [editInvoice, setEditInvoice] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => { fetchInvoices(); }, []);

  const fetchInvoices = async () => {
    setLoading(true);
    const { data } = await supabase.from('invoices').select('*').order('created_at', { ascending: false });
    setInvoices(data || []);
    setLoading(false);
  };

  const deleteInvoice = async (id) => {
    if (!window.confirm('Supprimer cette facture ?')) return;
    await supabase.from('invoices').delete().eq('id', id);
    fetchInvoices();
  };

  const logout = () => supabase.auth.signOut();

  const statusColor = s => s==='paid'?'#4ecca3':s==='pending'?'#ffb800':'#888480';
  const statusLabel = s => s==='paid'?'Payee':s==='pending'?'En attente':'Brouillon';

  if (view === 'new' || view === 'edit') {
    return <InvoiceEditor user={user} invoice={editInvoice} onSave={()=>{fetchInvoices();setView('list');setEditInvoice(null);}} onCancel={()=>{setView('list');setEditInvoice(null);}}/>;
  }

  return (
    <div style={{minHeight:'100vh',background:'#0b0b0c'}}>
      <nav style={{background:'rgba(11,11,12,.94)',backdropFilter:'blur(20px)',borderBottom:'1px solid rgba(255,255,255,.06)',height:64,padding:'0 28px',display:'flex',alignItems:'center',justifyContent:'space-between',position:'sticky',top:0,zIndex:99}}>
        <div style={{display:'flex',alignItems:'center',gap:11}}>
          <div style={{width:36,height:36,borderRadius:7,background:'linear-gradient(145deg,#e8c97a,#9a6e18)',display:'flex',alignItems:'center',justifyContent:'center',fontFamily:'Playfair Display,serif',fontWeight:700,fontSize:16,color:'#0b0b0c'}}>F</div>
          <span style={{fontFamily:'Playfair Display,serif',fontSize:16,fontWeight:600,letterSpacing:3,color:'#ede9df'}}>FACTURAPRO</span>
        </div>
        <div style={{display:'flex',alignItems:'center',gap:12}}>
          <span style={{fontSize:13,color:'#888480'}}>{user?.email}</span>
          <button onClick={logout} style={{padding:'6px 14px',border:'1px solid rgba(255,255,255,.1)',borderRadius:7,background:'transparent',color:'#888480',fontFamily:'DM Sans,sans-serif',fontSize:12,cursor:'pointer'}}>Deconnexion</button>
        </div>
      </nav>

      <div style={{maxWidth:900,margin:'0 auto',padding:'36px 18px'}}>
        <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:28}}>
          <div>
            <h1 style={{fontFamily:'Playfair Display,serif',fontSize:26,fontWeight:700,color:'#ede9df',marginBottom:4}}>Mes factures</h1>
            <p style={{fontSize:13,color:'#888480'}}>{invoices.length} facture{invoices.length!==1?'s':''} au total</p>
          </div>
          <button onClick={()=>{setEditInvoice(null);setView('new');}} style={{padding:'11px 22px',background:'linear-gradient(135deg,#d4a94e,#9a6e18)',color:'#0b0b0c',border:'none',borderRadius:9,fontFamily:'DM Sans,sans-serif',fontSize:13,fontWeight:700,cursor:'pointer',letterSpacing:1}}>
            + Nouvelle facture
          </button>
        </div>

        {loading ? (
          <div style={{textAlign:'center',padding:60,color:'#888480'}}>Chargement...</div>
        ) : invoices.length === 0 ? (
          <div style={{textAlign:'center',padding:80,background:'#131315',borderRadius:14,border:'1px solid rgba(255,255,255,.06)'}}>
            <p style={{fontSize:32,marginBottom:16}}>📄</p>
            <p style={{fontFamily:'Playfair Display,serif',fontSize:20,color:'#ede9df',marginBottom:8}}>Aucune facture</p>
            <p style={{fontSize:14,color:'#888480',marginBottom:24}}>Cree ta premiere facture maintenant</p>
            <button onClick={()=>setView('new')} style={{padding:'11px 24px',background:'linear-gradient(135deg,#d4a94e,#9a6e18)',color:'#0b0b0c',border:'none',borderRadius:9,fontFamily:'DM Sans,sans-serif',fontWeight:700,cursor:'pointer'}}>
              Creer une facture
            </button>
          </div>
        ) : (
          <div style={{display:'grid',gap:10}}>
            {invoices.map(inv=>(
              <div key={inv.id} style={{background:'#131315',border:'1px solid rgba(255,255,255,.06)',borderRadius:12,padding:'18px 22px',display:'flex',alignItems:'center',justifyContent:'space-between',transition:'border-color .2s',cursor:'pointer'}}
                onMouseEnter={e=>e.currentTarget.style.borderColor='rgba(201,168,76,.22)'}
                onMouseLeave={e=>e.currentTarget.style.borderColor='rgba(255,255,255,.06)'}>
                <div style={{display:'flex',alignItems:'center',gap:20}}>
                  <div>
                    <p style={{fontFamily:'Playfair Display,serif',fontSize:15,fontWeight:600,color:'#ede9df',marginBottom:3}}>#{inv.number}</p>
                    <p style={{fontSize:12,color:'#888480'}}>{inv.client_name||'Client non defini'}</p>
                  </div>
                  <div style={{display:'inline-flex',alignItems:'center',gap:5,padding:'3px 10px',borderRadius:20,fontSize:9,fontWeight:700,letterSpacing:1.5,textTransform:'uppercase',background:'rgba(255,185,0,.1)',color:statusColor(inv.status),border:'1px solid rgba(255,185,0,.2)'}}>
                    <span style={{width:4,height:4,borderRadius:'50%',background:statusColor(inv.status)}}/>
                    {statusLabel(inv.status)}
                  </div>
                </div>
                <div style={{display:'flex',alignItems:'center',gap:24}}>
                  <div style={{textAlign:'right'}}>
                    <p style={{fontFamily:'Playfair Display,serif',fontSize:18,fontWeight:700,color:'#c9a84c'}}>{Number(inv.total||0).toFixed(2)} CHF</p>
                    <p style={{fontSize:11,color:'#888480'}}>{inv.date}</p>
                  </div>
                  <div style={{display:'flex',gap:6}}>
                    <button onClick={()=>{setEditInvoice(inv);setView('edit');}} style={{padding:'6px 14px',border:'1px solid rgba(255,255,255,.1)',borderRadius:7,background:'transparent',color:'#ede9df',fontFamily:'DM Sans,sans-serif',fontSize:12,cursor:'pointer'}}>Editer</button>
                    <button onClick={()=>deleteInvoice(inv.id)} style={{padding:'6px 14px',border:'1px solid rgba(255,70,70,.2)',borderRadius:7,background:'transparent',color:'#ff6b6b',fontFamily:'DM Sans,sans-serif',fontSize:12,cursor:'pointer'}}>Sup.</button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
