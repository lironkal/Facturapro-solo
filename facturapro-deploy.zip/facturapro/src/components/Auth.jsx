import { useState } from 'react';
import { supabase } from '../lib/supabase';

export default function Auth() {
  const [mode, setMode] = useState('login'); // login | signup
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState('');

  const handle = async (e) => {
    e.preventDefault();
    setLoading(true);
    setMessage('');
    try {
      if (mode === 'signup') {
        const { error } = await supabase.auth.signUp({ email, password });
        if (error) throw error;
        setMessage('Verifie ton email pour confirmer ton compte !');
      } else {
        const { error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) throw error;
      }
    } catch (err) {
      setMessage(err.message);
    }
    setLoading(false);
  };

  return (
    <div style={{minHeight:'100vh',display:'flex',alignItems:'center',justifyContent:'center',background:'#0b0b0c',padding:20}}>
      <div style={{background:'#131315',border:'1px solid rgba(255,255,255,.06)',borderRadius:16,padding:'40px 36px',width:'100%',maxWidth:400}}>
        <div style={{display:'flex',alignItems:'center',gap:10,marginBottom:32}}>
          <div style={{width:36,height:36,borderRadius:7,background:'linear-gradient(145deg,#e8c97a,#9a6e18)',display:'flex',alignItems:'center',justifyContent:'center',fontFamily:'Playfair Display,serif',fontWeight:700,fontSize:16,color:'#0b0b0c',boxShadow:'0 0 18px rgba(201,168,76,.38)'}}>F</div>
          <span style={{fontFamily:'Playfair Display,serif',fontSize:16,fontWeight:600,letterSpacing:3,color:'#ede9df'}}>FACTURAPRO</span>
        </div>
        <h2 style={{fontFamily:'Playfair Display,serif',fontSize:22,fontWeight:600,color:'#ede9df',marginBottom:8}}>{mode==='login'?'Bienvenue':'Creer un compte'}</h2>
        <p style={{fontSize:13,color:'#888480',marginBottom:28}}>{mode==='login'?'Connecte-toi a ton compte':'Commence gratuitement'}</p>
        <form onSubmit={handle} style={{display:'flex',flexDirection:'column',gap:14}}>
          <input value={email} onChange={e=>setEmail(e.target.value)} type="email" placeholder="Email" required
            style={{padding:'11px 13px',background:'#1a1a1d',border:'1px solid rgba(255,255,255,.06)',borderRadius:8,color:'#ede9df',fontFamily:'DM Sans,sans-serif',fontSize:14,outline:'none'}}/>
          <input value={password} onChange={e=>setPassword(e.target.value)} type="password" placeholder="Mot de passe" required
            style={{padding:'11px 13px',background:'#1a1a1d',border:'1px solid rgba(255,255,255,.06)',borderRadius:8,color:'#ede9df',fontFamily:'DM Sans,sans-serif',fontSize:14,outline:'none'}}/>
          {message && <p style={{fontSize:12,color:'#c9a84c',background:'rgba(201,168,76,.08)',padding:'10px 12px',borderRadius:7,border:'1px solid rgba(201,168,76,.2)'}}>{message}</p>}
          <button type="submit" disabled={loading}
            style={{padding:14,background:'linear-gradient(135deg,#d4a94e,#9a6e18)',color:'#0b0b0c',border:'none',borderRadius:9,fontFamily:'DM Sans,sans-serif',fontSize:13,fontWeight:700,letterSpacing:2,textTransform:'uppercase',cursor:'pointer',marginTop:4}}>
            {loading?'...':(mode==='login'?'Se connecter':'Creer mon compte')}
          </button>
        </form>
        <p style={{marginTop:20,textAlign:'center',fontSize:13,color:'#888480'}}>
          {mode==='login'?'Pas de compte ?':'Deja un compte ?'}{' '}
          <button onClick={()=>setMode(mode==='login'?'signup':'login')} style={{background:'none',border:'none',color:'#c9a84c',cursor:'pointer',fontSize:13,fontFamily:'DM Sans,sans-serif'}}>
            {mode==='login'?'Creer un compte':'Se connecter'}
          </button>
        </p>
      </div>
    </div>
  );
}
