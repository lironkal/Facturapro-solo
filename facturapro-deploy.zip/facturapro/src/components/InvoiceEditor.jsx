import { useState, useRef } from 'react';
import { useReactToPrint } from 'react-to-print';
import { supabase } from '../lib/supabase';

const VAT = [0, 2.6, 3.8, 8.1];
const newInvoice = () => ({
  number: 'FAC-' + Date.now().toString().slice(-4),
  date: new Date().toISOString().split('T')[0],
  due_date: new Date(Date.now()+30*864e5).toISOString().split('T')[0],
  client_name:'', client_address:'', client_city:'', client_vat:'',
  vat_rate: 8.1, notes:'Paiement par virement bancaire.\nIBAN: CH00 0000 0000 0000 0000 0',
  items:[{desc:'',qty:1,price:0}], status:'pending'
});

function QR({size=90}){
  const n=21,c=size/n;
  const g=Array.from({length:n},(_,r)=>Array.from({length:n},(_,col)=>{
    if((r<7&&col<7)||(r<7&&col>=n-7)||(r>=n-7&&col<7))return 1;
    if(r===7||col===7)return 0;
    if(r>=8&&r<=12&&col>=8&&col<=12)return(r+col)%2===0?1:0;
    return Math.abs(Math.sin(r*13+col*7))>0.42?1:0;
  }));
  return(<svg width={size} height={size} viewBox={`0 0 ${size} ${size}`}><rect width={size} height={size} fill="white"/>{g.flatMap((row,r)=>row.map((v,col)=>v?<rect key={r+'-'+col} x={col*c} y={r*c} width={c} height={c} fill="#18130d"/>:null))}</svg>);
}

const CSS = `
*{box-sizing:border-box;margin:0;padding:0}
:root{--g:#c9a84c;--gl:#e8c97a;--gd:rgba(201,168,76,.12);--bg:#0b0b0c;--s1:#131315;--s2:#1a1a1d;--bd:rgba(255,255,255,.06);--bdg:rgba(201,168,76,.22);--tx:#ede9df;--m1:#505050;--m2:#888480}
html,body{background:var(--bg);color:var(--tx);font-family:'DM Sans',sans-serif}
.ed{max-width:900px;margin:0 auto;padding:28px 18px;display:grid;gap:16px}
.card{background:var(--s1);border:1px solid var(--bd);border-radius:13px;padding:22px 24px;transition:border-color .25s}
.card:hover{border-color:var(--bdg)}
.ct{font-size:9px;letter-spacing:3.5px;color:var(--g);text-transform:uppercase;font-weight:600;display:flex;align-items:center;gap:10px;margin-bottom:18px}
.ct::after{content:'';flex:1;height:1px;background:linear-gradient(90deg,rgba(201,168,76,.28),transparent)}
.g3{display:grid;grid-template-columns:1fr 1fr 1fr;gap:12px}
.g2{display:grid;grid-template-columns:1fr 1fr;gap:14px}
.col{display:flex;flex-direction:column;gap:11px}
.f{display:flex;flex-direction:column;gap:5px}
.fl{font-size:9px;letter-spacing:2px;color:var(--m1);text-transform:uppercase;font-weight:600}
.i{padding:10px 12px;background:var(--s2);border:1px solid var(--bd);border-radius:8px;color:var(--tx);font-family:'DM Sans',sans-serif;font-size:14px;width:100%;outline:none;transition:.2s}
.i:focus{border-color:var(--g);box-shadow:0 0 0 3px rgba(201,168,76,.1)}
.i::placeholder{color:var(--m1)}
.ih{display:grid;grid-template-columns:1fr 70px 120px 110px 30px;gap:8px;margin-bottom:8px}
.ih span{font-size:9px;letter-spacing:2px;color:var(--m1);text-transform:uppercase;font-weight:600}
.ir{display:grid;grid-template-columns:1fr 70px 120px 110px 30px;gap:8px;margin-bottom:8px;align-items:center}
.itot{padding:10px 11px;background:rgba(201,168,76,.07);border:1px solid rgba(201,168,76,.18);border-radius:8px;font-size:14px;font-weight:600;color:var(--gl);text-align:right}
.rb{width:30px;height:30px;border-radius:7px;background:transparent;border:1px solid transparent;color:var(--m1);font-size:17px;cursor:pointer;display:flex;align-items:center;justify-content:center;transition:.2s;padding:0}
.rb:hover{background:rgba(255,70,70,.1);color:#ff6b6b;border-color:rgba(255,70,70,.2)}
.ab{margin-top:8px;padding:8px 16px;border:1px dashed rgba(201,168,76,.32);border-radius:8px;background:transparent;color:var(--g);font-family:'DM Sans',sans-serif;font-size:13px;cursor:pointer;transition:.2s}
.ab:hover{background:var(--gd);border-color:var(--g)}
.tots{margin-top:18px;padding-top:16px;border-top:1px solid var(--bd);display:flex;flex-direction:column;align-items:flex-end;gap:9px}
.tr{display:flex;align-items:center;gap:16px;font-size:14px;color:var(--m2)}
.tr span:last-child{min-width:145px;text-align:right;color:var(--tx);font-weight:500}
.vs{padding:5px 9px;background:var(--s2);border:1px solid var(--bd);border-radius:7px;color:var(--tx);font-family:'DM Sans',sans-serif;font-size:13px;cursor:pointer;outline:none}
.gb{background:linear-gradient(135deg,rgba(201,168,76,.13),rgba(201,168,76,.04));border:1px solid rgba(201,168,76,.26);border-radius:11px;padding:13px 18px;display:flex;align-items:center;gap:24px;margin-top:2px}
.gbl{font-size:10px;letter-spacing:3px;color:var(--g);text-transform:uppercase;font-weight:600}
.gba{font-family:'Playfair Display',serif;font-size:26px;font-weight:700;color:var(--gl);min-width:155px;text-align:right}
.ta{width:100%;padding:10px 12px;background:var(--s2);border:1px solid var(--bd);border-radius:8px;color:var(--tx);font-family:'DM Sans',sans-serif;font-size:14px;resize:vertical;outline:none;line-height:1.65;transition:.2s}
.ta:focus{border-color:var(--g);box-shadow:0 0 0 3px rgba(201,168,76,.1)}
.actions{display:flex;gap:10px}
.pbtn{flex:1;padding:14px;background:linear-gradient(135deg,#d4a94e,#9a6e18);color:#0b0b0c;border:none;border-radius:10px;font-family:'DM Sans',sans-serif;font-size:13px;font-weight:700;letter-spacing:2px;text-transform:uppercase;cursor:pointer;transition:.3s}
.pbtn:hover{box-shadow:0 6px 28px rgba(201,168,76,.42);transform:translateY(-1px)}
.sbtn{padding:14px 24px;background:transparent;color:var(--m2);border:1px solid rgba(255,255,255,.1);border-radius:10px;font-family:'DM Sans',sans-serif;font-size:13px;cursor:pointer;transition:.2s}
.sbtn:hover{color:var(--tx);border-color:rgba(255,255,255,.25)}
@media print{
  body{background:white}
  .no-print{display:none!important}
  .print-only{display:block!important}
}
`;

const INVOICE_PRINT_CSS = `
  body{font-family:'DM Sans',sans-serif;background:white;color:#1c1810}
  .invoice-print{max-width:800px;margin:0 auto;background:#f8f5ef}
  .inv-hdr{background:#17120c;padding:40px 48px;display:flex;justify-content:space-between;position:relative;overflow:hidden}
  .inv-hdr::after{content:'';position:absolute;bottom:0;left:0;right:0;height:1px;background:linear-gradient(90deg,transparent,rgba(201,168,76,.6),transparent)}
  .inv-num{font-family:'Playfair Display',serif;font-size:32px;font-weight:700;color:#f8f5ef}
  .inv-lbl{font-size:9px;letter-spacing:4px;color:#c9a84c;text-transform:uppercase;margin-bottom:8px}
  .inv-due{font-family:'Playfair Display',serif;font-size:16px;color:#c9a84c;font-weight:600}
  .inv-body{padding:40px 48px}
  .parties{display:grid;grid-template-columns:1fr 1fr;gap:40px;margin-bottom:36px}
  .party-lbl{font-size:9px;letter-spacing:3px;color:#c9a84c;text-transform:uppercase;margin-bottom:8px}
  .party-name{font-family:'Playfair Display',serif;font-size:15px;font-weight:600;color:#1c1810;margin-bottom:4px}
  .party-info{font-size:12px;color:#787068;line-height:1.8;white-space:pre-line}
  table{width:100%;border-collapse:collapse;margin-bottom:24px}
  thead tr{border-bottom:2px solid #1c1810}
  th{padding:8px 8px 10px;font-size:9px;letter-spacing:2px;color:#a09890;text-transform:uppercase;font-weight:500}
  th:first-child{text-align:left}th:not(:first-child){text-align:right}
  td{padding:12px 8px;font-size:13px;border-bottom:1px solid #ede8de}
  td:not(:first-child){text-align:right;color:#78706a}
  td.bold{font-weight:600;color:#1c1810}
  .totals-row{display:flex;justify-content:space-between;padding:6px 0;border-bottom:1px solid #ede8de;font-size:13px;color:#989088}
  .grand-total{display:flex;justify-content:space-between;padding:13px 0 0;font-family:'Playfair Display',serif;font-size:20px;font-weight:700;border-top:2px solid #1c1810}
  .grand-total span:last-child{color:#c9a84c}
  .qr-section{border:1px solid #e0d8cc;border-radius:7px;padding:20px;display:flex;gap:20px;align-items:center;background:#f2ede4;margin-top:28px}
  .footer{padding:16px 48px;background:#ece7de;text-align:center;font-size:9px;letter-spacing:3px;color:#b8b0a4;text-transform:uppercase}
`;

export default function InvoiceEditor({ user, invoice, onSave, onCancel }) {
  const [form, setForm] = useState(invoice || newInvoice());
  const [viewMode, setViewMode] = useState('edit');
  const [saving, setSaving] = useState(false);
  const [profile, setProfile] = useState(null);
  const printRef = useRef();

  const set = (k,v) => setForm(f=>({...f,[k]:v}));
  const si = (i,k,v) => setForm(f=>({...f,items:f.items.map((x,j)=>j===i?{...x,[k]:v}:x)}));
  const sub = form.items.reduce((s,x)=>s+Number(x.qty)*Number(x.price),0);
  const vt = sub*form.vat_rate/100;
  const tot = sub+vt;
  const fmt = d=>{try{return new Date(d+'T12:00:00').toLocaleDateString('fr-CH',{day:'2-digit',month:'long',year:'numeric'})}catch{return d}};

  const handlePrint = useReactToPrint({ content: ()=>printRef.current });

  const save = async () => {
    setSaving(true);
    const data = { ...form, subtotal:sub, vat_amount:vt, total:tot, user_id:user.id };
    if (invoice?.id) {
      await supabase.from('invoices').update(data).eq('id', invoice.id);
    } else {
      await supabase.from('invoices').insert([data]);
    }
    setSaving(false);
    onSave();
  };

  return (
    <>
    <style>{CSS}</style>
    <div>
      <nav className="no-print" style={{background:'rgba(11,11,12,.94)',backdropFilter:'blur(20px)',borderBottom:'1px solid rgba(255,255,255,.06)',height:60,padding:'0 24px',display:'flex',alignItems:'center',justifyContent:'space-between',position:'sticky',top:0,zIndex:99}}>
        <div style={{display:'flex',alignItems:'center',gap:8}}>
          <button onClick={onCancel} style={{background:'none',border:'none',color:'#888480',cursor:'pointer',fontSize:13,fontFamily:'DM Sans,sans-serif'}}>← Retour</button>
          <span style={{color:'rgba(255,255,255,.2)'}}>|</span>
          <span style={{fontSize:13,color:'#ede9df',fontFamily:'Playfair Display,serif'}}>Facture #{form.number}</span>
        </div>
        <div style={{display:'flex',gap:6}}>
          {['edit','preview'].map(v=>(
            <button key={v} onClick={()=>setViewMode(v)} style={{padding:'6px 14px',border:'none',borderRadius:7,fontFamily:'DM Sans,sans-serif',fontSize:11,fontWeight:500,letterSpacing:1.5,cursor:'pointer',textTransform:'uppercase',background:viewMode===v?'#c9a84c':'transparent',color:viewMode===v?'#0b0b0c':'#888480'}}>
              {v==='edit'?'Editer':'Apercu'}
            </button>
          ))}
        </div>
      </nav>

      {viewMode==='edit' ? (
        <div className="ed">
          <div className="card">
            <div className="ct">Informations</div>
            <div className="g3">
              {[['Numero','number','text'],['Date','date','date'],['Echeance','due_date','date']].map(([l,k,t])=>(
                <div className="f" key={k}><label className="fl">{l}</label><input className="i" type={t} value={form[k]} onChange={e=>set(k,e.target.value)}/></div>
              ))}
            </div>
          </div>
          <div className="card">
            <div className="ct">Client</div>
            <div className="g2">
              {[['Nom','client_name'],['Adresse','client_address'],['Ville NPA','client_city'],['N TVA','client_vat']].map(([l,k])=>(
                <div className="f" key={k}><label className="fl">{l}</label><input className="i" value={form[k]} onChange={e=>set(k,e.target.value)} placeholder={l}/></div>
              ))}
            </div>
          </div>
          <div className="card">
            <div className="ct">Prestations</div>
            <div className="ih">{['Description','Qte','Prix unit.','Total CHF',''].map(h=><span key={h}>{h}</span>)}</div>
            {form.items.map((x,i)=>(
              <div className="ir" key={i}>
                <input className="i" value={x.desc} onChange={e=>si(i,'desc',e.target.value)} placeholder="Description..."/>
                <input className="i" type="number" value={x.qty} onChange={e=>si(i,'qty',e.target.value)} style={{textAlign:'center'}} min="1"/>
                <input className="i" type="number" value={x.price} onChange={e=>si(i,'price',e.target.value)} style={{textAlign:'right'}} min="0"/>
                <div className="itot">{(x.qty*x.price).toFixed(2)}</div>
                <button className="rb" onClick={()=>setForm(f=>({...f,items:f.items.filter((_,j)=>j!==i)}))}>x</button>
              </div>
            ))}
            <button className="ab" onClick={()=>setForm(f=>({...f,items:[...f.items,{desc:'',qty:1,price:0}]}))}>+ Ajouter</button>
            <div className="tots">
              <div className="tr"><span>Sous-total HT</span><span>{sub.toFixed(2)} CHF</span></div>
              <div className="tr">
                <span>TVA</span>
                <select className="vs" value={form.vat_rate} onChange={e=>set('vat_rate',Number(e.target.value))}>{VAT.map(r=><option key={r} value={r}>{r}%</option>)}</select>
                <span>{vt.toFixed(2)} CHF</span>
              </div>
              <div className="gb"><span className="gbl">Total TTC</span><span className="gba">{tot.toFixed(2)} CHF</span></div>
            </div>
          </div>
          <div className="card">
            <div className="ct">Notes et IBAN</div>
            <textarea className="ta" rows={3} value={form.notes} onChange={e=>set('notes',e.target.value)}/>
          </div>
          <div className="actions no-print">
            <button className="sbtn" onClick={onCancel}>Annuler</button>
            <button className="pbtn" onClick={save} disabled={saving}>{saving?'Sauvegarde...':'Sauvegarder la facture'}</button>
          </div>
        </div>
      ) : (
        <div style={{maxWidth:790,margin:'24px auto',padding:'0 18px 40px'}}>
          <div style={{display:'flex',gap:10,marginBottom:20}} className="no-print">
            <button onClick={onCancel} style={{padding:'10px 22px',border:'1px solid rgba(255,255,255,.12)',borderRadius:8,background:'#131315',color:'#888480',fontFamily:'DM Sans,sans-serif',fontSize:12,cursor:'pointer'}}>← Retour</button>
            <button onClick={save} disabled={saving} style={{padding:'10px 22px',border:'1px solid rgba(201,168,76,.3)',borderRadius:8,background:'transparent',color:'#c9a84c',fontFamily:'DM Sans,sans-serif',fontSize:12,cursor:'pointer'}}>{saving?'...':'Sauvegarder'}</button>
            <button onClick={handlePrint} style={{padding:'10px 22px',border:'none',borderRadius:8,background:'linear-gradient(135deg,#d4a94e,#9a6e18)',color:'#0b0b0c',fontFamily:'DM Sans,sans-serif',fontSize:12,fontWeight:700,cursor:'pointer'}}>Imprimer / PDF</button>
          </div>
          <div ref={printRef} className="invoice-print" style={{background:'#f8f5ef',borderRadius:5,overflow:'hidden',boxShadow:'0 20px 80px rgba(0,0,0,.65)'}}>
            <style>{INVOICE_PRINT_CSS}</style>
            <div className="inv-hdr">
              <div>
                <div className="inv-lbl">Facture</div>
                <div className="inv-num">#{form.number}</div>
              </div>
              <div style={{textAlign:'right'}}>
                <div style={{fontSize:9,letterSpacing:3,color:'#5a5248',textTransform:'uppercase',marginBottom:3}}>Emission</div>
                <div style={{fontSize:13,color:'#f8f5ef',marginBottom:11}}>{fmt(form.date)}</div>
                <div style={{fontSize:9,letterSpacing:3,color:'#5a5248',textTransform:'uppercase',marginBottom:3}}>Echeance</div>
                <div className="inv-due">{fmt(form.due_date)}</div>
              </div>
            </div>
            <div className="inv-body">
              <div className="parties">
                <div>
                  <div className="party-lbl">Client</div>
                  <div className="party-name">{form.client_name||'--'}</div>
                  <div className="party-info">{[form.client_address,form.client_city,form.client_vat?'TVA: '+form.client_vat:''].filter(Boolean).join('\n')}</div>
                </div>
              </div>
              <table>
                <thead><tr><th style={{textAlign:'left'}}>Description</th><th>Qte</th><th>Prix unit.</th><th>Total CHF</th></tr></thead>
                <tbody>{form.items.filter(x=>x.desc).map((x,i)=><tr key={i}><td>{x.desc}</td><td>{x.qty}</td><td>{Number(x.price).toFixed(2)}</td><td className="bold">{(x.qty*x.price).toFixed(2)}</td></tr>)}</tbody>
              </table>
              <div style={{display:'flex',justifyContent:'flex-end',marginBottom:20}}>
                <div style={{minWidth:260}}>
                  {[['Sous-total HT',sub.toFixed(2)],['TVA '+form.vat_rate+'%',vt.toFixed(2)]].map(([l,v])=>(
                    <div key={l} className="totals-row"><span>{l}</span><span>{v} CHF</span></div>
                  ))}
                  <div className="grand-total"><span>Total TTC</span><span>{tot.toFixed(2)} CHF</span></div>
                </div>
              </div>
              <div className="qr-section">
                <QR size={85}/>
                <div>
                  <div style={{fontSize:9,letterSpacing:3,color:'#c9a84c',textTransform:'uppercase',fontWeight:600,marginBottom:8}}>QR-Facture Swiss Payment</div>
                  <div style={{fontSize:12,color:'#686058',lineHeight:2}}><strong>Montant:</strong> {tot.toFixed(2)} CHF<br/><strong>Reference:</strong> {form.number}</div>
                </div>
                <div style={{fontSize:11,color:'#989088',lineHeight:1.8,paddingLeft:20,whiteSpace:'pre-line',borderLeft:'1px solid #ddd8ce',marginLeft:4}}>{form.notes}</div>
              </div>
            </div>
            <div className="footer"><span>FacturaPro - Facturation Suisse</span></div>
          </div>
        </div>
      )}
    </div>
    </>
  );
}
