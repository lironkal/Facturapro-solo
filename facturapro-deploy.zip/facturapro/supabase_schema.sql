-- Run this in your Supabase SQL editor

-- Enable UUID extension
create extension if not exists "uuid-ossp";

-- Profiles table (linked to auth.users)
create table profiles (
  id uuid references auth.users primary key,
  email text,
  full_name text,
  company_name text,
  address text,
  city text,
  vat_number text,
  iban text,
  plan text default 'free',
  created_at timestamp default now()
);

-- Invoices table
create table invoices (
  id uuid default uuid_generate_v4() primary key,
  user_id uuid references profiles(id) on delete cascade,
  number text not null,
  date date not null,
  due_date date not null,
  client_name text,
  client_address text,
  client_city text,
  client_vat text,
  vat_rate numeric default 8.1,
  notes text,
  status text default 'pending',
  items jsonb default '[]',
  subtotal numeric default 0,
  vat_amount numeric default 0,
  total numeric default 0,
  created_at timestamp default now()
);

-- Row Level Security
alter table profiles enable row level security;
alter table invoices enable row level security;

-- Policies: users can only see their own data
create policy "Users see own profile" on profiles for all using (auth.uid() = id);
create policy "Users manage own invoices" on invoices for all using (auth.uid() = user_id);

-- Auto-create profile on signup
create function handle_new_user() returns trigger as $$
begin
  insert into profiles (id, email) values (new.id, new.email);
  return new;
end;
$$ language plpgsql security definer;

create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure handle_new_user();
